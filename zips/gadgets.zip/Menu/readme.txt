Menu V1.0 by Iain King, (C)1998 MacharSoft

This is a small demo application written in UniComal, using the
Gadgets module.

To run:
	
	Run using the GUIMenu.bat file.  DO NOT RUN Gadgmenu.exe - it will
not work.

The Menu reads in a file called Menulist.txt, which should be in the same
directory.  Menulist.txt determines what the menu options to display are.
Here is an example file:

----------------------snip--------------------------------
Label=Plasma
Oneline=Draws a Plasma (fractalesque).  Looks pretty
Extra=Ctrl-Break to exit, Any key to advance.
Extra=Space will toggle block/point estimation.
Extra=The colour schemes will cycle through a few presets.
Program=demos\plasma.exe

Label=Fireworks
Oneline=Fireworks display for your PC
Extra=Ctrl-Break to quit
Extra=Screen may appear motionless, but just wait for the
Extra=rockets to get up there!  Enjoy the show.
Program=comal demos\fireworks
----------------------snip--------------------------------

LABEL will be displayed in the button you click to select 
	  that item.

ONELINE will be displayed next to that button

EXTRA lines will be displayed at the bottom of the screen when
      that item is selected.  There MUST be three Extra lines.

PROGRAM is the line which will be passed to the shell when the
		Run button is hit.


Extra notes:
	
	The example Menulist.txt will run some programs in the Demos 
directory.  Some of these programs are comal source, and the Menu
requires that the Comal directory is in the command path.  If it is not
then you can add it to the command path by typing:

	SET PATH=%PATH%;C:\COMAL