Gadgets Module V1.2 by Iain King, (C)1998 by MacharSoft

Pack contents:

    Example.cml             Example file using Gadgets
    Uservars.cml            Default config file for Gadgets
    Install.exe             Installation file
    Gadgets.hlp             UniComal compiled help file
    Gadgets.mod             The Gadgets module file
    Readme.txt              This file
    listings/               ASCII source for the above files
        Example.lst             ASCII source for Example.cml
        Gadgets.lst             ASCII source for Gadgets.mod
        Uservars.lst            ASCII source for Uservars.cml
        Helpfile.txt            ASCII source for Gadgets.hlp
    Menu/                   Menu application written with Gadgets
        GUIMenu.bat             Batch file needed to run the Menu
        Gadgmenu.exe            Menu executable
        Menulist.txt            Items in the menu are stored in this file
        Readme.txt              Instructions for using the Menu
        Demos/                  Demo files that the Menu will run
            3D.cml                  Spinning 3D helix
            Firework.cml            Fireworks display
            Lens.cml                Lens magnifier
            Muncher.cml             Munching squares
            Star.cml                Probability fill
            Test2.cpf               Picture for use with Lens.cml
            Plasma.exe              Plasma fractal drawer
            Swarm.exe               Wasps swarm simulator
        Source/                 Source for the Menu program
            Gadgmenu.arf            Build file for the ComalC compiler
            Gadgmenu.cml            The Menu program
            Uservars.cml            Configuration file for Gadgets
            Menuitem.mod            Module for reading in the Menulist file
            Gadgmenu.lst            ASCII source for Gadgmenu.cml
            Menuitem.lst            ASCII source for Menuitem.mod
            Uservars.lst            ASCII source for Uservars.cml



Installation:

    Unzip the package to a temporary directory (for example, c:\temp), then
    either use the 'Install.exe' installation file, or manually:
    
    Assuming your Comal directory is at 'C:\COMAL'.  If it is not, then
    replace all 'C:\COMAL's with the appropriate path.

    Place the Gadgets.mod file in C:\COMAL\MODULES
    Place the Gadgets.hlp file in C:\COMAL\US

    Place all other files in whatever location you wish the gadgets module
    to occupy.  For example, I keep all my programs in C:\COMAL\STUFF, so
    I put the rest of the files in C:\COMAL\STUFF\GADGETS

    Edit the C:\COMAL\COMAL.PRO file, appending this line to the end:

        HELPFILE "C:\COMAL\US\GADGETS.HLP"

Version history:

    V 1.0       First release

    V 1.1       Added Cycle Gadget, and it's related procedures.
                Changed the look of the GUI slightly (softened it).

	V 1.2		BUG - changed# function was not exported - now it is
				Sliders now no longer flicker (previously a *very* 
				stupid alogrithm)