This ZIP should contain:

  UniGo.exe			-		The Game
  Go.cml			-		Source
  Uservars.cml		-		Source (neccessary for gadgets module)
  Go.lst			-		ASCII list of Go.cml
  Uservars.lst		-		ASCII list of Uservars.cml
  Go.arf			-		Compiler file for UniGO
  Go.txt			-		Instructions for UniGo
  readme.txt		-		This file
  
  
Installation:

	Simply unzip the archive to a directory of you choice (you could make one called 'UniGo').
	
	To run the program just run UniGo.exe - none of the other files are neccessary.